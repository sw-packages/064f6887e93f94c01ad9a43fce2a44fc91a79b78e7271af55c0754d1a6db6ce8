import QtQml

QtObject {}
